package agridrone.model;

public class Item extends ItemAbstract{
	public Item(String name, int x, int y, int w, int l, int price) {
		super(name, x, y, w, l, price);
	}
}
