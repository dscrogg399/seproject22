package agridrone.model;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class Drone extends Item{
	
	public Drone(String name, int x, int y, int w, int l, int price) {
		super(name, x, y, w, l, price);
		
	}
	
	
	SequentialTransition sequence = new SequentialTransition();
	SequentialTransition sequence2 = new SequentialTransition();
	SequentialTransition sequence3 = new SequentialTransition();
	SequentialTransition sequence4 = new SequentialTransition();
	SequentialTransition sequence5 = new SequentialTransition();
	SequentialTransition sequence6 = new SequentialTransition();
	SequentialTransition sequence7 = new SequentialTransition();
	SequentialTransition sequence8 = new SequentialTransition();
	
	
	TranslateTransition translate = new TranslateTransition();
	TranslateTransition translate2 = new TranslateTransition();
	TranslateTransition translate3 = new TranslateTransition();
	TranslateTransition translate4 = new TranslateTransition();
	TranslateTransition translate5 = new TranslateTransition();
	TranslateTransition translate6 = new TranslateTransition();
	TranslateTransition translate7 = new TranslateTransition();
	TranslateTransition translate8 = new TranslateTransition();
	TranslateTransition translate9 = new TranslateTransition();
	
	
	
	
	
	
	public void gotoItem(ItemAbstract item, ImageView drone) {
		translate7.setNode(drone);
		translate7.setDuration(Duration.millis(1000));
		if ((this.getLocationX() != item.getLocationX()) || (this.getLocationY() != item.getLocationY())) {
			double itemx = 0;
			double itemy = 0;
			itemx = item.getLocationX() - drone.getLayoutX();
			itemy = item.getLocationY() - drone.getLayoutY();
			
			translate7.setToX(itemx);
			translate7.setToY(itemy);
			
			
			this.setLocationX(item.getLocationX());
			this.setLocationY(item.getLocationY());
			sequence.stop();
			sequence = new SequentialTransition(translate7);
			sequence.play();
			
		} else {
			System.out.println("Drone currently at " + item.getName() + ".");
		}
	}
	
	public void gotoParent(ImageView drone) {
		translate8.setNode(drone);
		translate8.setDuration(Duration.millis(1000));
		
		if ((this.getLocationX() != this.getParentContainer().getLocationX()) || (this.getLocationY() != this.getParentContainer().getLocationY())) {
			//goto parent
			
			translate8.setToX(-drone.getLayoutX() + this.getParentContainer().getLocationX());
			translate8.setToY(-drone.getLayoutY() - (-this.getParentContainer().getLocationY()));
			
			this.setLocationX(this.getParentContainer().getLocationX());
			this.setLocationY(this.getParentContainer().getLocationY());
			
			sequence.stop();
			sequence = new SequentialTransition(translate8);
			sequence.play();
		} else {
			System.out.println("Drone currently at " + this.getName() + ".");
		}
	}
	
	
	
	
	public void scanFarm(double VH, double VW, ImageView drone) {
		//scanFarm
		translate.setNode(drone);
		translate2.setNode(drone);
		translate3.setNode(drone);
		translate4.setNode(drone);
		translate5.setNode(drone);
		translate6.setNode(drone);
		translate7.setNode(drone);
		Duration time = Duration.millis(1000);
		translate.setDuration(time);
		translate2.setDuration(time);
		translate3.setDuration(time);
		translate4.setDuration(time);
		translate5.setDuration(time);
		translate5.setDuration(time);

		translate.setToX(-drone.getLayoutX());
		translate.setToY(-drone.getLayoutY());
		
		translate2.setByX(VW*2.6);
		translate3.setByY(this.getLength());
		translate4.setByX(-VW*2.6);
		translate5.setByY(this.getLength());
		
		
		translate6.setToX(-drone.getLayoutX() + this.getParentContainer().getLocationX());
		translate6.setToY(-drone.getLayoutY() - (-this.getParentContainer().getLocationY()));
		
		
		
		
		sequence2 = new SequentialTransition(translate2, translate3, translate4, translate5 );
		sequence3 = new SequentialTransition(translate2, translate3, translate4, translate5 );
		sequence4 = new SequentialTransition(translate2, translate3, translate4, translate5 );
		sequence5 = new SequentialTransition(translate2, translate3, translate4, translate5 );
		sequence6 = new SequentialTransition(translate2, translate3, translate4, translate5 );
		sequence7 = new SequentialTransition(translate2, translate3, translate4, translate5 );
		sequence8 = new SequentialTransition(translate6);
		sequence = new SequentialTransition(translate, sequence2, sequence3, sequence4, sequence5, sequence6,sequence7, sequence8);
		sequence.play();
		
		
		
		this.setLocationX(this.getParentContainer().getLocationX());
		this.setLocationY(this.getParentContainer().getLocationY());
		
	};

	
}
