package agridrone.model;


public class ItemContainer extends ItemAbstract {
	
	public ItemContainer(String name, int x, int y, int w, int l, int price) {
		super(name, x, y, w, l, price);
	}


}
