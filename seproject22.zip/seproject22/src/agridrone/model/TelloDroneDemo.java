package agridrone.model;

import java.io.IOException;

public class TelloDroneDemo {
	
	private static Drone drone;
	private static void flight() throws IOException, InterruptedException{
		TelloDrone tello = new TelloDrone(drone);
		tello.examplefly();
	}
	
	public static void main(String[] args) throws IOException, InterruptedException{
		flight();
		System.exit(0);
	}

}
